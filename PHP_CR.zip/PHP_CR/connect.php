<?php

$conn=new mysqli('localhost','root','','crud');
if($conn){
    
}else{
    die(mysqli_error($conn));
}
?>